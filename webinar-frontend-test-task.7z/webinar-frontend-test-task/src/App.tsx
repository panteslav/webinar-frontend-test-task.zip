import React, { useCallback } from 'react';
import Container from '@material-ui/core/Container';
import Typography from '@material-ui/core/Typography';
import { createMuiTheme } from '@material-ui/core/styles';
import { ThemeProvider } from '@material-ui/styles';
import { TodoItemsList } from './Components/TodoItems/TodoItems';
import {
    TodoItemsContextProvider,
    useTodoItems,
} from './Components/TodoItemsContext';
import TodoItemForm from './Components/TodoItemForm';
import { Box, Button, makeStyles } from '@material-ui/core';

const theme = createMuiTheme({
    palette: {
        primary: {
            main: '#9012fe',
        },
        secondary: {
            main: '#b2aabf',
        },
    },
});

function App() {
    return (
        <TodoItemsContextProvider>
            <ThemeProvider theme={theme}>
                <Content />
            </ThemeProvider>
        </TodoItemsContextProvider>
    );
}

function Content() {
    const { dispatch } = useTodoItems();
    const handleClear = useCallback(() => dispatch({ type: 'clearAll' }), []);

    const useBoxStyles = makeStyles({
        root: {
            display: 'flex',
            justifyContent: 'right',
        },
    });
    const classes = useBoxStyles();

    return (
        <Container maxWidth="sm">
            <header>
                <Typography variant="h2" component="h1">
                    Todo List
                </Typography>
            </header>
            <main>
                <TodoItemForm />
                <TodoItemsList />
                <Box className={classes.root}>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleClear}
                    >
                        Clear all
                    </Button>
                </Box>
            </main>
        </Container>
    );
}

export default App;
