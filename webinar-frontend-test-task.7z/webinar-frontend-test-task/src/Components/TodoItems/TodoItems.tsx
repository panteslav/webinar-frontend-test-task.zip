import React, { useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { TodoItem, useTodoItems } from '../TodoItemsContext';
import {
    DragDropContext,
    Droppable,
    DropResult,
    DroppableProvided,
} from 'react-beautiful-dnd';
import DraggableItem from './DraggableItem';
import { motion } from 'framer-motion';

const useTodoItemListStyles = makeStyles({
    root: {
        listStyle: 'none',
        padding: 0,
    },
});

export const TodoItemsList = function () {
    const { todoItems, dispatch } = useTodoItems();
    const classes = useTodoItemListStyles();
    const handleDragEnd = useCallback(
        (id: string, index: number) =>
            dispatch({
                type: 'setNewOrder',
                data: { id, index },
            }),
        [dispatch]
    );

    const spring = {
        type: 'spring',
        damping: 25,
        stiffness: 120,
        duration: 0.25,
    };

    const onDragEnd = (result: DropResult) => {
        const { source, destination, draggableId } = result;
        if (!destination) return;
        if (
            destination.droppableId === source.droppableId &&
            destination.index === source.index
        ) {
            return;
        }
        const newIndex = destination.index;

        handleDragEnd(draggableId, newIndex);
    };

    return (
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="todo">
                {(provided: DroppableProvided) => (
                    <ul
                        className={classes.root}
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                    >
                        {todoItems.map((item: TodoItem, index: number) => {
                            return (
                                <motion.li key={item.id} transition={spring}>
                                    <DraggableItem
                                        item={item}
                                        index={index}
                                        key={item.id}
                                    />
                                </motion.li>
                            );
                        })}
                        {provided.placeholder}
                    </ul>
                )}
            </Droppable>
        </DragDropContext>
    );
};
